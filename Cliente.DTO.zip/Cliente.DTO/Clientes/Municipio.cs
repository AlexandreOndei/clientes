﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cliente.DTO.Clientes
{
    public class Municipio
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Sigla_Estado { get; set; }
    }
}

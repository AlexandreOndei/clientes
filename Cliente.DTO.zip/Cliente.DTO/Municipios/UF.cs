﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cliente.DTO.Municipios
{
    public class UF
    {
        public string nome { get; set; }
        public string sigla { get; set; }
    }
}

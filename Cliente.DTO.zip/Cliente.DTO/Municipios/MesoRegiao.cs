﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cliente.DTO.Municipios
{
    public class MesoRegiao
    {
        public UF UF { get; set; }
    }
}
